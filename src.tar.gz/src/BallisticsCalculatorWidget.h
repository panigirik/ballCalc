#ifndef BALLISTICSCALCULATORWIDGET_H
#define BALLISTICSCALCULATORWIDGET_H

#include <QWidget>
#include <QVector>
#include <QLineEdit>
#include <QDial>
#include <QLabel>
#include <QComboBox>
#include <QTableWidget>
#include <QPushButton>

class BallisticsCalculatorWidget : public QWidget {
    Q_OBJECT

public:
    explicit BallisticsCalculatorWidget(QWidget *parent = nullptr);

private slots:
    void updateClickUnit();
    void showGraph();
    void updateTableRowCount();
    void calculateBallistics();
    QVector<double> calculateBallistics_drops(); // Corrected function declaration
    void updateWindDirection(int value);
    void dateToFile();

private:
    QLineEdit *inputVelocity;
    QLineEdit *inputAngle;
    QLineEdit *inputCaliber;
    QLineEdit *inputMass;
    QLineEdit *inputBC;
    QLineEdit *inputTemp;
    QLineEdit *inputPressure;
    QLineEdit *inputHumidity;
    QLineEdit *inputWindSpeed;
    QLineEdit *inputMaxDistance;
    QLineEdit *inputDistanceStep;
    QLineEdit *inputYrdGroup;
    QLineEdit *inputAltitude;
    QLineEdit *inputSight;
    QLineEdit *inputZeroRange;
    QLineEdit *inputTwist;
    QLineEdit *inputClickValue;
    QLineEdit *inputBulletLength;
    QLineEdit *inputZapas_Vert;
    QLineEdit *inputZapas_Hor;
    QComboBox *inputScopeUnits;
    QDial *windDirectionDial;
    QLabel *windDirectionLabel;
    QLabel *clickUnitLabel;
    QLabel *resultLabel;
    QPushButton *calculateButton;
    QPushButton *dateToFileButton;
    QTableWidget *correctionTable;

    QVector<double> distances;
    QVector<double> drops;

    void setBulletTrajectory(const QVector<double> &distances, const QVector<double> &drops);
};

#endif // BALLISTICSCALCULATORWIDGET_H
