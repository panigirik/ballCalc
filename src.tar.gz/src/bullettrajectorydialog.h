#ifndef BULLETTRAJECTORYDIALOG_H
#define BULLETTRAJECTORYDIALOG_H

#include <QDialog>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>

QT_BEGIN_NAMESPACE
namespace Ui {
    class BulletTrajectoryDialog;
}
QT_END_NAMESPACE

class BulletTrajectoryDialog : public QDialog {
    Q_OBJECT

public:
    explicit BulletTrajectoryDialog(QWidget *parent = nullptr);
    ~BulletTrajectoryDialog();
    void setBulletTrajectory(const QVector<double> &distance, const QVector<double> &drop);

private:
    QtCharts::QChartView *chartView;

};

#endif // BULLETTRAJECTORYDIALOG_H
