#include "customchartview.h"

CustomChartView::CustomChartView(QChart *chart, const QVector<double> &distances, const QVector<double> &drops, QWidget *parent)
    : QChartView(chart, parent), distances(distances), drops(drops) {
    tooltip = new QGraphicsSimpleTextItem(chart);
    tooltip->setZValue(11);
    tooltip->setPos(this->rect().center());
    tooltip->setText("Hover over the graph to see details");
    tooltip->setVisible(false);
}

void CustomChartView::mouseMoveEvent(QMouseEvent *event) {
    QPointF point = this->chart()->mapToValue(event->pos());
    if (point.x() < 0 || point.x() > distances.last() || point.y() < drops.last() || point.y() > drops.first()) {
        tooltip->setVisible(false);
        return;
    }

    int closestIndex = 0;
    double closestDistance = qAbs(distances[0] - point.x());
    for (int i = 1; i < distances.size(); ++i) {
        double distance = qAbs(distances[i] - point.x());
        if (distance < closestDistance) {
            closestDistance = distance;
            closestIndex = i;
        }
    }

    QPointF closestPoint(distances[closestIndex], drops[closestIndex]);
    QPointF position = this->chart()->mapToPosition(closestPoint);
    tooltip->setPos(position);
    tooltip->setText(QString("Distance: %1 m\nDrop: %2 in").arg(closestPoint.x()).arg(closestPoint.y()));
    tooltip->setVisible(true);

    QChartView::mouseMoveEvent(event);
}
