#include <QApplication>
#include "BallisticsCalculatorWidget.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    BallisticsCalculatorWidget widget;
    widget.setWindowTitle("Баллистический калькулятор");
    //widget.setBack
    widget.showMaximized();

    return app.exec();
}
