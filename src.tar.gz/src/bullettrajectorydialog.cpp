#include "bullettrajectorydialog.h"
#include <QVBoxLayout>


BulletTrajectoryDialog::BulletTrajectoryDialog(QWidget *parent) :
    QDialog(parent),
    chartView(new QtCharts::QChartView(this))
{
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(chartView);
    setLayout(layout);


    resize(1800, 800);
}

BulletTrajectoryDialog::~BulletTrajectoryDialog() {
    delete chartView;
}

void BulletTrajectoryDialog::setBulletTrajectory(const QVector<double> &distance, const QVector<double> &drop) {
    // Создаем серию данных для графика
    QtCharts::QLineSeries *series = new QtCharts::QLineSeries();

    // Заполняем серию данными о дистанции и падении пули
    for (int i = 0; i < distance.size(); ++i) {
        // перевод падение пули из дюймов в MOA
        double dropInches = drop[i];
        double dropMOA = dropInches;
        // добавление каждой точки тракетории на график
        series->append(distance[i], dropMOA);
    }

    // Получаем ссылку на график из QChartView
    QtCharts::QChart *chart = chartView->chart();

    // очистка графика в случае расчета при других заходных данных
    chart->removeAllSeries();

    // добавление точек на график
    chart->addSeries(series);

    chart->createDefaultAxes();


    // обновление отображения графика
    chartView->update();
}

