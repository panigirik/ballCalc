#ifndef CUSTOMCHARTVIEW_H
#define CUSTOMCHARTVIEW_H

#include <QtCharts/QChartView>
#include <QGraphicsSimpleTextItem>
#include <QMouseEvent>

QT_CHARTS_USE_NAMESPACE

class CustomChartView : public QChartView {
    Q_OBJECT

public:
    CustomChartView(QChart *chart, const QVector<double> &distances, const QVector<double> &drops, QWidget *parent = nullptr);

protected:
    void mouseMoveEvent(QMouseEvent *event) override;

private:
    QGraphicsSimpleTextItem *tooltip;
    QVector<double> distances;
    QVector<double> drops;
};

#endif // CUSTOMCHARTVIEW_H
