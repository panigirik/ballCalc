#include "BallisticsCalculatorWidget.h"
#include "Ballistics.h"
#include <QGridLayout>
#include <QMessageBox>
#include <QHeaderView>
#include <cmath>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QStringList>
#include <QString>
#include <QComboBox>
#include <QFileDialog>
#include <QChartView>
#include <qchartview.h>
#include "bullettrajectorydialog.h"
#include <QPushButton>
//////
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QChartView>
#include <QGraphicsSimpleTextItem>
#include <QLineSeries>
#include <QValueAxis>
#include "customchartview.h"

using namespace std;


QT_CHARTS_USE_NAMESPACE

Ballistics ballistics;

BallisticsCalculatorWidget::BallisticsCalculatorWidget(QWidget *parent) : QWidget(parent) {
    auto *layout = new QGridLayout(this);

    inputVelocity = new QLineEdit(this);
    inputAngle = new QLineEdit();
    inputCaliber = new QLineEdit();
    inputMass = new QLineEdit();
    inputBC = new QLineEdit();
    inputTemp = new QLineEdit();
    inputPressure = new QLineEdit();
    inputHumidity = new QLineEdit();
    inputWindSpeed = new QLineEdit();
    inputMaxDistance = new QLineEdit();
    inputDistanceStep = new QLineEdit();
    inputYrdGroup = new QLineEdit();
    inputAltitude = new QLineEdit();

    windDirectionDial = new QDial();
    windDirectionDial->setRange(0, 360);
    windDirectionDial->setSingleStep(1);
    windDirectionDial->setFixedSize(120, 120);
    windDirectionDial->setWrapping(true);
    windDirectionDial->setNotchesVisible(true);
    windDirectionLabel = new QLabel("0°");
    windDirectionLabel->setAlignment(Qt::AlignCenter);
    windDirectionLabel->setFixedSize(30, 30);
    inputSight = new QLineEdit();
    inputZeroRange = new QLineEdit();
    inputTwist = new QLineEdit();
    inputClickValue = new QLineEdit();
    inputBulletLength = new QLineEdit();
    inputZapas_Vert = new QLineEdit();
    inputZapas_Hor = new QLineEdit();
    inputScopeUnits = new QComboBox();
    inputScopeUnits->addItem("MOA");
    inputScopeUnits->addItem("MRAD");

    dateToFileButton = new QPushButton("Занести данные в файл");
    connect(dateToFileButton, &QPushButton::clicked, this, &BallisticsCalculatorWidget::dateToFile);

    calculateButton = new QPushButton("Рассчитать");
    calculateButton->setFixedSize(200, 40);
    resultLabel = new QLabel("Результаты будут показаны здесь ----->");

    layout->addWidget(new QLabel("Данные о пуле: "), 0, 0);
    layout->addWidget(new QLabel("Скорость (фут/с):"), 1, 0);
    layout->addWidget(inputVelocity, 1, 1);
    layout->addWidget(new QLabel("Калибр (in):"), 2, 0);
    layout->addWidget(inputCaliber, 2, 1);
    layout->addWidget(new QLabel("Угол (градусы):"), 3, 0);
    layout->addWidget(inputAngle, 3, 1);
    layout->addWidget(new QLabel("Масса (граны):"), 4, 0);
    layout->addWidget(inputMass, 4, 1);
    layout->addWidget(new QLabel("БК(G7):"), 5, 0);
    layout->addWidget(inputBC, 5, 1);

    layout->addWidget(new QLabel("Данные об атмосфере: "), 0, 2);
    layout->addWidget(new QLabel("Температура (F): "), 1, 2);
    layout->addWidget(inputTemp, 1, 3);
    layout->addWidget(new QLabel("Атмосферное давление (дюймы рт. ст.):"), 2, 2);
    layout->addWidget(inputPressure, 2, 3);
    layout->addWidget(new QLabel("Влажность воздуха (%):"), 3, 2);
    layout->addWidget(inputHumidity, 3, 3);
    layout->addWidget(new QLabel("Скорость ветра (mph):"), 4, 2);
    layout->addWidget(inputWindSpeed, 4, 3);

    layout->addWidget(new QLabel("Данные о стрельбе: "), 0, 4);
    layout->addWidget(new QLabel("Высота линии прицеливания (in): "), 1, 4);
    layout->addWidget(inputSight, 1, 5);
    layout->addWidget(new QLabel("Дистанция нулевой пристрелки (yrds):"), 2, 4);
    layout->addWidget(inputZeroRange, 2, 5);
    layout->addWidget(new QLabel("Шаг нарезов (in):"), 3, 4);
    layout->addWidget(inputTwist, 3, 5);
    layout->addWidget(new QLabel("Длина пули (in):"), 4, 4);
    layout->addWidget(inputBulletLength, 4, 5);
    layout->addWidget(new QLabel("Максимальная дистанция (ярды):"), 2, 6);
    layout->addWidget(inputMaxDistance, 2, 7);

    layout->addWidget(new QLabel("Данные о прицеле:"), 0, 6);
    clickUnitLabel = new QLabel("Цена одного клика:");
    layout->addWidget(clickUnitLabel, 1, 6);
    layout->addWidget(inputClickValue, 1, 7);

    layout->addWidget(new QLabel("Шаг дистанции (yrds):"), 9, 3);
    layout->addWidget(inputDistanceStep, 9, 4);
    layout->addWidget(new QLabel("Группа на дистанции в 100 ярдов(in)"), 9, 5);
    layout->addWidget(inputYrdGroup, 9, 6);

    layout->addWidget(new QLabel("Запас поправок по вертикали:"), 3, 6);
    layout->addWidget(inputZapas_Vert, 3, 7);
    layout->addWidget(new QLabel("Запас поправок по горизонтали: "), 4, 6);
    layout->addWidget(inputZapas_Hor, 4, 7);
    layout->addWidget(new QLabel("Единицы измерения прицела:"), 5, 6);
    layout->addWidget(inputScopeUnits, 5, 7);

    layout->addWidget(calculateButton, 6, 0, 1, 6);
    layout->addWidget(resultLabel, 7, 0, 1, 6);
    layout->addWidget(dateToFileButton, 9, 1);

    layout->addWidget(new QLabel("         Направление ветра(в градусах):"), 5, 2);
    layout->addWidget(windDirectionDial, 5, 3);
    windDirectionLabel->setParent(windDirectionDial);

    correctionTable = new QTableWidget(10, 6);
    correctionTable->setHorizontalHeaderLabels({"Горизонтальная поправка(MOA)", "Вертикальная поправка(MOA)", "Горизонтальная поправка(MRAD)", "Вертикальная поправка(MRAD)", "Кучность(in)", "Дистанция(yrds)"});
    QHeaderView *header = correctionTable->horizontalHeader();
    header->setSectionResizeMode(QHeaderView::Stretch);

    layout->addWidget(correctionTable, 8, 0, 1, 8);
    correctionTable->clearContents();

    QPushButton *showGraphButton = new QPushButton("График траектории", this);
    layout->addWidget(showGraphButton, 10, 0);

    setLayout(layout);

    connect(inputScopeUnits, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &BallisticsCalculatorWidget::updateClickUnit);
    connect(calculateButton, &QPushButton::clicked, this, &BallisticsCalculatorWidget::calculateBallistics);
    connect(windDirectionDial, &QDial::valueChanged, this, &BallisticsCalculatorWidget::updateWindDirection);
    connect(inputDistanceStep, &QLineEdit::textChanged, this, &BallisticsCalculatorWidget::updateTableRowCount);
    connect(inputMaxDistance, &QLineEdit::textChanged, this, &BallisticsCalculatorWidget::updateTableRowCount);
    connect(inputDistanceStep, &QLineEdit::textChanged, this, &BallisticsCalculatorWidget::updateTableRowCount);
    connect(showGraphButton, &QPushButton::clicked, this, &BallisticsCalculatorWidget::showGraph);
}

void BallisticsCalculatorWidget::updateClickUnit() {
    QString unit = inputScopeUnits->currentText();
    clickUnitLabel->setText(QString("Цена одного клика (%1):").arg(unit));
}


void BallisticsCalculatorWidget::setBulletTrajectory(const QVector<double> &distances, const QVector<double> &drops) {
    QLineSeries *series = new QLineSeries();
    for (int i = 0; i < distances.size(); ++i) {
        series->append(distances[i], drops[i]);
    }

    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Траектория");
    chart->createDefaultAxes();
    //chart->axisX()->setTitleText("Distance (m)");
    //chart->axisY()->setTitleText("Drop (in)");

    CustomChartView *chartView = new CustomChartView(chart, distances, drops);
    chartView->resize(1920, 1700);
    chartView->setRenderHint(QPainter::Antialiasing);
    chartView->setWindowTitle("Траектория");
    chartView->show();
}



void BallisticsCalculatorWidget::showGraph() {

    // Вызов showGraph() только после того, как данные готовы для отображения на графике

    distances.clear();
    drops.clear();


    drops = calculateBallistics_drops();

    // Заполенение различными шагами дистанции
    double distanceStep = inputDistanceStep->text().toDouble();
    for (int i = 0; i < correctionTable->rowCount(); ++i) {
        double distance = (i + 1) * distanceStep;
        distances.append(distance);
    }

    // Если не удалось рассчитать
    if (drops.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Не удалось рассчитать падение пули.");
        return;
    }

    // Вызов сетода
    setBulletTrajectory(distances, drops);


}




void BallisticsCalculatorWidget::updateTableRowCount() {
    bool ok;
    double maxDistance = inputMaxDistance->text().toDouble(&ok);
    if (!ok || maxDistance <= 0) {
        QMessageBox::warning(this, "Ошибка ввода", "Введите значение максимальной дистанции.");
        return;
    }

    double distanceStep = inputDistanceStep->text().toDouble(&ok);
    int numRows = static_cast<int>(std::ceil(maxDistance / distanceStep));
    correctionTable->setRowCount(numRows);

    for (int i = 0; i < numRows; ++i) {
        double currentDistance = i * distanceStep;
        correctionTable->setItem(i, 0, new QTableWidgetItem(QString::number(currentDistance)));
        correctionTable->setItem(i, 1, new QTableWidgetItem(QString::number(currentDistance + distanceStep)));
        correctionTable->setItem(i, 2, new QTableWidgetItem(QString::number(currentDistance + 2 * distanceStep)));
    }
}


void BallisticsCalculatorWidget::dateToFile() {
    // Отображение диалогового окна для сохранения файла
    QString filePath = QFileDialog::getSaveFileName(this, tr("Сохранить файл"), QDir::homePath(), tr("Текстовые файлы (*.txt)"));

    if (filePath.isEmpty()) {
        qDebug() << "Отменено пользователем.";
        return;
    }

    QFile file(filePath);

    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);

        // Установка кодировки UTF-8
        out.setCodec("UTF-8");

        // Запись заголовков в файл на английском
        out << "Horizontal Correction (MOA)\tVertical Correction (MOA)\tHorizontal Correction (MRAD)\tVertical Correction (MRAD)\tGrouping(in)\tDistance(yrds)\n";

        // Запись данных таблицы в файл
        for (int i = 0; i < correctionTable->rowCount(); ++i) {
            QTableWidgetItem *hor_moa_item = correctionTable->item(i, 0);
            QTableWidgetItem *vert_moa_item = correctionTable->item(i, 1);
            QTableWidgetItem *hor_mrad_item = correctionTable->item(i, 2);
            QTableWidgetItem *vert_mrad_item = correctionTable->item(i, 3);
            QTableWidgetItem *grouping_item = correctionTable->item(i, 4);
            QTableWidgetItem *distance_item = correctionTable->item(i, 5);

            if (!hor_moa_item || !vert_moa_item || !hor_mrad_item || !vert_mrad_item || !grouping_item || !distance_item) {
                qDebug() << "Ошибка: элемент не установлен для строки" << i;
                continue;
            }

            QString hor_moa_correction = hor_moa_item->text().leftJustified(10, ' ');
            QString vert_moa_correction = vert_moa_item->text().leftJustified(10, ' ');
            QString hor_mrad_correction = hor_mrad_item->text().leftJustified(10, ' ');
            QString vert_mrad_correction = vert_mrad_item->text().leftJustified(10, ' ');
            QString grouping = grouping_item->text().leftJustified(10, ' ');
            QString distance = distance_item->text().leftJustified(10, ' ');

            // Удаление лишних пробелов и символов
            hor_moa_correction = hor_moa_correction.simplified();
            vert_moa_correction = vert_moa_correction.simplified();
            hor_mrad_correction = hor_mrad_correction.simplified();
            vert_mrad_correction = vert_mrad_correction.simplified();
            grouping = grouping.simplified();
            distance = distance.simplified();

            // Форматирование строки в виде таблицы
            out << hor_moa_correction << "\t" << "\t" << "\t" << "\t" << vert_moa_correction << "\t" << "\t" << "\t" << "\t" << hor_mrad_correction << "\t"  << "\t" << "\t" << "\t" << vert_mrad_correction << "\t" << "\t" << "\t" << "\t" << grouping << "\t" << "\t" << distance;

            // Добавление разделительных символов "_"
            if (i < correctionTable->rowCount() - 1) {
                out << "\n___________________________________________________________________________________________________________________________________________________________\n";
            }
        }

        file.close();
        qDebug() << "Данные таблицы записаны в файл: " << file.fileName();
    } else {
        qDebug() << "Ошибка при открытии файла для записи.";
    }
}






void BallisticsCalculatorWidget::calculateBallistics() {
    // Извлекаем входные значения
    double velocity = inputVelocity->text().toDouble();
    double angle = inputAngle->text().toDouble();
    double caliber = inputCaliber->text().toDouble();
    double mass = inputMass->text().toDouble();
    double BC = inputBC->text().toDouble();
    double temperature = inputTemp->text().toDouble();
    double pressure = inputPressure->text().toDouble();
    double humidity = inputHumidity->text().toDouble();
    double windSpeed = inputWindSpeed->text().toDouble();
    double windDirection = windDirectionDial->value();
    double sight = inputSight->text().toDouble();
    double zeroRange = inputZeroRange->text().toDouble();
    double twist = inputTwist->text().toDouble();
    double bulletLength = inputBulletLength->text().toDouble();
    double YrdGroup = inputYrdGroup->text().toDouble();
    double Zapas_Vert = inputZapas_Vert->text().toDouble();
    double Zapas_Hor = inputZapas_Hor->text().toDouble();
    double maxDistance = inputMaxDistance->text().toDouble();
    double altitude = inputAltitude->text().toDouble();
    double clickValue = inputClickValue->text().toDouble();

    // Проверка, чтобы все поля были заполнены
    if (inputVelocity->text().isEmpty() ||
        inputAngle->text().isEmpty() ||
        inputCaliber->text().isEmpty() ||
        inputMass->text().isEmpty() ||
        inputBC->text().isEmpty() ||
        inputTemp->text().isEmpty() ||
        inputPressure->text().isEmpty() ||
        inputHumidity->text().isEmpty() ||
        inputWindSpeed->text().isEmpty() ||
        inputSight->text().isEmpty() ||
        inputZeroRange->text().isEmpty() ||
        inputTwist->text().isEmpty() ||
        inputBulletLength->text().isEmpty() ||
        inputZapas_Vert->text().isEmpty() ||
        inputZapas_Hor->text().isEmpty() ||
        inputMaxDistance->text().isEmpty() ||
        inputDistanceStep->text().isEmpty() ||
        inputYrdGroup->text().isEmpty() ||
        inputClickValue->text().isEmpty())
    {
        QMessageBox::warning(this, "Недостаточно данных", "Пожалуйста, заполните все поля корректными данными!");
        return; // Выход из функции, если не все поля заполнены
    }

    QVector<double> distances;
    QVector<double> drops;

    // Заполнение данных о дистанции и падении пули
    for (int i = 0; i < correctionTable->rowCount(); ++i) {
        double distance = (i + 1) * inputDistanceStep->text().toDouble();
        distances.append(distance);

        // Вычисление вертикального падения
        double dropInches = ballistics.calculateVerticalDrop(velocity, BC, angle, distance, windSpeed, windDirection, sight, altitude, pressure, temperature, humidity, zeroRange);
        drops.append(dropInches);

        double hor_moa = ballistics.calculate_HOR(velocity, angle, caliber, mass, BC, temperature, pressure, humidity, windSpeed, sight, zeroRange, twist, bulletLength, windDirection, Zapas_Hor, Zapas_Vert, distance, altitude);
        double vert_moa = ballistics.calculateMOA_VERT(velocity, angle, caliber, mass, BC, temperature, pressure, humidity, windSpeed, sight, zeroRange, twist, bulletLength, windDirection, Zapas_Hor, Zapas_Vert, distance, altitude);
        double hor_mrad = hor_moa / 3.4377;
        double vert_mrad = vert_moa / 3.4377;
        double grouping = ballistics.calculateGroup(distance, YrdGroup);

        correctionTable->setItem(i, 0, new QTableWidgetItem(QString::number(hor_moa, 'f', 2)));
        correctionTable->setItem(i, 1, new QTableWidgetItem(QString::number(vert_moa, 'f', 2)));
        correctionTable->setItem(i, 2, new QTableWidgetItem(QString::number(hor_mrad, 'f', 2)));
        correctionTable->setItem(i, 3, new QTableWidgetItem(QString::number(vert_mrad, 'f', 2)));
        correctionTable->setItem(i, 4, new QTableWidgetItem(QString::number(grouping, 'f', 2)));
        correctionTable->setItem(i, 5, new QTableWidgetItem(QString::number(distance, 'f', 2)));
    }



    // Рассчеты для вывода на экран
    QString selectedUnit = inputScopeUnits->currentText();
    if (selectedUnit == "MOA") {
        double hor_moa = ballistics.calculate_HOR(velocity, angle, caliber, mass, BC, temperature, pressure, humidity, windSpeed, sight, zeroRange, twist, bulletLength, windDirection, Zapas_Hor, Zapas_Vert, maxDistance, altitude);
        double vert_moa = ballistics.calculateMOA_VERT(velocity, angle, caliber, mass, BC, temperature, pressure, humidity, windSpeed, sight, zeroRange, twist, bulletLength, windDirection, Zapas_Hor, Zapas_Vert, maxDistance, altitude);
        double drop = ballistics.calculateVerticalDrop(velocity, BC, angle, maxDistance, windSpeed, windDirection, sight, altitude, pressure, temperature, humidity, zeroRange);
        double SG = ballistics.calculateSG(mass, twist, bulletLength, caliber, velocity, temperature, pressure);
        double hor_clicks_moa = hor_moa / clickValue;
        double vert_clicks_moa = vert_moa / clickValue;
        double time = ballistics.calculateFlightTime(velocity, angle, caliber, mass, BC,
                                                     temperature, pressure, humidity, windSpeed,
                                                     sight, zeroRange, twist, bulletLength,
                                                     windDirection, Zapas_Hor, Zapas_Vert, maxDistance);
        resultLabel->setText(QString("Горизонтальная поправка: %1 MOA   Вертикальная поправка: %2 MOA   Фактор гироскопической стабильности: %3   Падение: %4   Клики(гор): %5   Клики(верт): %6   Время полета: %7").arg(hor_moa).arg(vert_moa).arg(SG).arg(drop).arg(hor_clicks_moa).arg(vert_clicks_moa).arg(time));

        if (Zapas_Hor < hor_clicks_moa) {
            QString message = QString("Не хватает запаса кликов по горизонтали, вынос по сетке(MOA): %1").arg(hor_moa - Zapas_Hor);
            QMessageBox::information(this, "Недостаточно кликов", message);
        } else if (Zapas_Vert < -vert_clicks_moa) {
            QString message = QString("Не хватает запаса кликов по вертикали, вынос по сетке(MOA): %1").arg(vert_moa - Zapas_Vert);
            QMessageBox::information(this, "Недостаточно кликов", message);
        }
    } else if (selectedUnit == "MRAD") {
        double hor_mrad = ballistics.calculate_HOR(velocity, angle, caliber, mass, BC, temperature, pressure, humidity, windSpeed, sight, zeroRange, twist, bulletLength, windDirection, Zapas_Hor, Zapas_Vert, maxDistance, altitude) / 3.4377;
        double vert_mrad = ballistics.calculateMOA_VERT(velocity, angle, caliber, mass, BC, temperature, pressure, humidity, windSpeed, sight, zeroRange, twist, bulletLength, windDirection, Zapas_Hor, Zapas_Vert, maxDistance, altitude) / 3.4377;
        double drop = ballistics.calculateVerticalDrop(velocity, BC, angle, maxDistance, windSpeed, windDirection, sight, altitude, pressure, temperature, humidity, zeroRange);
        double SG = ballistics.calculateSG(mass, twist, bulletLength, caliber, velocity, temperature, pressure);
        double hor_clicks_mrad = hor_mrad / clickValue;
        double vert_clicks_mrad = vert_mrad / clickValue;
        double time = ballistics.calculateFlightTime(velocity, angle, caliber, mass, BC,
                                                     temperature, pressure, humidity, windSpeed,
                                                     sight, zeroRange, twist, bulletLength,
                                                     windDirection, Zapas_Hor, Zapas_Vert, maxDistance);
        resultLabel->setText(QString("Горизонтальная поправка: %1 MRAD   Вертикальная поправка: %2 MRAD   Фактор гироскопической стабильности: %3   Падение: %4   Клики(гор): %5   Клики(верт): %6 Время полета: %7").arg(hor_mrad).arg(vert_mrad).arg(SG).arg(drop).arg(hor_clicks_mrad).arg(vert_clicks_mrad).arg(time));

        if (Zapas_Hor < hor_clicks_mrad) {
            QString message = QString("Не хватает запаса кликов по горизонтали, вынос по сетке(MRAD): %1").arg(hor_mrad - Zapas_Hor);
            QMessageBox::information(this, "Недостаточно кликов", message);
        } else if (Zapas_Vert < -vert_clicks_mrad) {
            QString message = QString("Не хватает запаса кликов по вертикали, вынос по сетке(MRAD): %1").arg(vert_mrad - Zapas_Vert);
            QMessageBox::information(this, "Недостаточно кликов", message);
        }
    }
}


QVector<double> BallisticsCalculatorWidget::calculateBallistics_drops() {
    QVector<double> drops;

    // Извлечение всех введенных значений из полей
    double velocity = inputVelocity->text().toDouble();
    double angle = inputAngle->text().toDouble();
    double BC = inputBC->text().toDouble();
    double temperature = inputTemp->text().toDouble();
    double pressure = inputPressure->text().toDouble();
    double humidity = inputHumidity->text().toDouble();
    double windSpeed = inputWindSpeed->text().toDouble();
    double windDirection = windDirectionDial->value();
    double sight = inputSight->text().toDouble();
    double zeroRange = inputZeroRange->text().toDouble();
    double altitude = inputAltitude->text().toDouble();

    // Проверка, что все поля заполнены и заполнены корректно
    if (inputVelocity->text().isEmpty() ||
        inputAngle->text().isEmpty() ||
        inputCaliber->text().isEmpty() ||
        inputMass->text().isEmpty() ||
        inputBC->text().isEmpty() ||
        inputTemp->text().isEmpty() ||
        inputPressure->text().isEmpty() ||
        inputHumidity->text().isEmpty() ||
        inputWindSpeed->text().isEmpty() ||
        inputSight->text().isEmpty() ||
        inputZeroRange->text().isEmpty() ||
        inputTwist->text().isEmpty() ||
        inputBulletLength->text().isEmpty() ||
        inputZapas_Vert->text().isEmpty() ||
        inputZapas_Hor->text().isEmpty() ||
        inputMaxDistance->text().isEmpty() ||
        inputDistanceStep->text().isEmpty() ||
        inputYrdGroup->text().isEmpty() ||
        inputClickValue->text().isEmpty())
    {
        QMessageBox::warning(this, "Недостаточно данных", "Пожалуйста, заполните все поля корректными данными!");
        return QVector<double>(); // Return an empty vector if not all fields are filled
    }

    // Заноим дистанцию на каждом шаге
    for (int i = 0; i < correctionTable->rowCount(); ++i) {
        double distance = (i + 1) * inputDistanceStep->text().toDouble();

        // Calculate vertical drop
        double dropInches = ballistics.calculateVerticalDrop(velocity, BC, angle, distance, windSpeed, windDirection, sight, altitude, pressure, temperature, humidity, zeroRange);
        drops.append(dropInches);



    }

    return drops;
}


// обновление значения,  которое отвечает за напрвление ветра
void BallisticsCalculatorWidget::updateWindDirection(int value) {
    windDirectionLabel->setText(QString::number(value) + "°");
}



