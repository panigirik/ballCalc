#include "Ballistics.h"
#include "/home/zahar/libballistics/include/ballistics/ballistics.h"
#include <cmath>
#include <algorithm>

Ballistics::Ballistics() {

}

Ballistics::~Ballistics() {

}







double Ballistics::calculate_HOR(double velocity, double angle, double caliber, double mass, double BC,
                                 double temperature, double pressure, double humidity, double windSpeed,
                                 double sight, double zeroRange, double twist, double bulletLength,
                                 double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude) {
    // Рассчитываем реальное время полета снаряда
    double HOR = calculateHorizontalDrift(velocity, BC, angle, distance, windSpeed, windDirection, sight, altitude, pressure, temperature, humidity, zeroRange) ;

    return (HOR / (distance / 100)) ;
}




double Ballistics::calculateMOA_VERT(double velocity, double angle, double caliber, double mass, double BC,
                                      double temperature, double pressure, double humidity, double windSpeed,
                                      double sight, double zeroRange, double twist, double bulletLength,
                                      double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude) {

    double DROP = calculateVerticalDrop(velocity, BC, angle, distance, windSpeed, windDirection, sight, altitude, pressure, temperature, humidity, zeroRange);

    return DROP / (distance / 100);
}





double Ballistics::calculateMOA_HOR(double velocity, double angle, double caliber, double mass, double BC,
                                    double temperature, double pressure, double humidity, double windSpeed,
                                    double sight, double zeroRange, double twist, double bulletLength,
                                    double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude) {
    double DRIFT = calculate_HOR(velocity, angle, caliber, mass, BC,
                                 temperature, pressure, humidity, windSpeed,
                                 sight, zeroRange, twist, bulletLength,
                                 windDirection, Zapas_Hor, Zapas_Vert, distance, altitude);


    if (distance < 0) {
        distance = -distance;
    }

    return DRIFT / (distance / 100);
}



double Ballistics::calculateSG(double mass, double twist, double bulletLength, double caliber, double velocity, double temperature, double pressure) {

    double SG = (30 * mass)/(pow((twist/caliber), 2) * pow(caliber, 3) * (bulletLength/caliber) * (1 + pow((bulletLength/caliber), 2)));
    double VelovityK = pow((velocity/2800), 1/3);
    double AtmoK = ((temperature + 460) * 29.92) / (519 * pressure);
    double result = SG * VelovityK * AtmoK;
    return result;
}




double Ballistics::calculateGroup(double distance, double YrdGroup){
    double NewGroup = YrdGroup * distance / 100 * 1.3;
    return NewGroup;
}



double Ballistics::calculateFlightTime(double velocity, double angle, double caliber, double mass, double BC,
                                       double temperature, double pressure, double humidity, double windSpeed,
                                       double sight, double zeroRange, double twist, double bulletLength,
                                       double windDirection, double Zapas_Hor, double Zapas_Vert, double distance) {
    // Convert angle to radians
    double angle_rad = angle * M_PI / 180.0;

    // Initial velocities
    double vx = velocity * cos(angle_rad);
    double vy = velocity * sin(angle_rad);

    // Initialize position variables
    double x = 0;
    double y = sight / 12.0; // sight is converted from inches to feet

    // Initialize time variables
    double t = 0;
    double dt = 0.001; // Smaller time step for higher accuracy
    double max_time = 10.0;

    // Altitude placeholder (assuming a value here, it should be passed as a parameter or calculated)
    double altitude = 0; // Modify as needed

    // Loop to calculate the flight time
    while (t < max_time) {
        // Calculate the velocity magnitude
        double v = sqrt(vx * vx + vy * vy);

        // Correct the ballistic coefficient for atmospheric conditions
        double correctedBC = atmosphereCorrection(BC, altitude, pressure, temperature, humidity);

        // Calculate the drag force
        double dv = retard(G7, correctedBC, v);

        // Update the velocities
        double dvx = -dv * vx / v * dt;
        double dvy = (-dv * vy / v - GRAVITY) * dt;

        vx += dvx;
        vy += dvy;

        // Update positions
        x += vx * dt;
        y += vy * dt;

        // Check if the bullet has hit the ground or reached the specified distance
        if (y <= 0 || x >= distance * 3.28084) { // Convert distance from meters to feet
            break;
        }

        // Update the time
        t += dt;

        // Dynamic time step adjustment based on velocity
        dt = std::max(0.001, 0.5 / v); // Ensure dt doesn't go below a minimum threshold
    }

    // Return the time of flight
    return t;
}



double Ballistics::calculateMRAD_HOR(double velocity, double angle, double caliber, double mass, double BC, double temperature, double pressure, double humidity, double windSpeed, double sight, double zeroRange, double twist, double bulletLength, double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude){

    double DRIFT = calculate_HOR(velocity, angle, caliber, mass,  BC,
                               temperature,  pressure, humidity,  windSpeed,
                              sight,  zeroRange, twist,  bulletLength,
                              windDirection,  Zapas_Hor,  Zapas_Vert, distance, altitude);
    return (distance / 100) / (DRIFT / 2.54);
}

double Ballistics::calculateMRAD_VERT(double velocity, double angle, double caliber, double mass, double BC,
                          double temperature, double pressure, double humidity, double windSpeed,
                          double sight, double zeroRange, double twist, double bulletLength,
                          double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude){

    double DROP = calculateVerticalDrop(velocity, BC, angle, distance, windSpeed, windDirection, sight, altitude, pressure, temperature, humidity, zeroRange);

    return (distance / 100) / (DROP / 2.54);
}


double inline Ballistics::calculateVerticalDrop( double velocity, double BC, double angle, double distance, double windSpeed, double windDirection, double sight, double altitude, double pressure, double temperature, double humidity, double zeroRange) {
    //distance = distance - 60;

    //double corBC = atmosphereCorrection(BC, altitude,  pressure,  temperature, humidity);
    double zeroAngle = calculateZeroAngle(velocity, sight, zeroRange, G7, BC, 0); // Use the zero_angle function to calculate the zero angle
    double t = 0;
    double dt = 0;
    double v = 0;
    double vx = 0, vx1 = 0, vy = 0, vy1 = 0;
    double dv = 0, dvx = 0, dvy = 0;
    double x = 0, y = 0;
    //double BC_COR = atmosphereCorrection(BC, altitude, pressure, temperature, humidity);

    double hwind = headwind(windSpeed, windDirection, angle);
    //double cwind = crosswind(windSpeed, windDirection);
    double gx = GRAVITY*sin(deg_to_rad((angle + zeroAngle)));
    double gy = GRAVITY*cos(deg_to_rad((angle + zeroAngle)));

    vx = (velocity) * cos(deg_to_rad(zeroAngle)); // Increase the initial velocity
    vy = (velocity) * sin(deg_to_rad(zeroAngle)); // Increase the initial velocity

    y = -sight / 12; // y is in feet

    for (t = 0;; t = t + dt) {
        vx1 = vx;
        vy1 = vy;
        v = sqrt(vx * vx + vy * vy);
        dt = 0.01 / v; // Use adaptive time step

        // Compute acceleration using the drag function retardation
        dv = retard(G7, BC , v + hwind); // Include headwind in retardation calculation
        dvx = -(vx / v) * dv;
        dvy = -(vy / v) * dv;

        // Compute velocity, including the resolved gravity vectors.
        vx = vx + dt * dvx + dt * gx;
        vy = vy + dt * dvy + dt * gy;

        // Compute position based on average velocity.
        x = x + dt * (vx + vx1) / 2;
        y = y + dt * (vy + vy1) / 2;

        if (x / 3 >= distance || fabs(vy) > fabs(3 * vx))
            break;
    }

    return y * 12; // Convert vertical drop to inches
}




static inline double calcRelativeHumidity(double temperature, double pressure, double humidity) {
    double VPw=4e-6*pow(temperature,3) - 0.0004*pow(temperature,2)+0.0234*temperature-0.2517;
    double frh=0.995*(pressure/(pressure-(0.3783)*(humidity)*VPw));
    return frh;
}

static inline double calcPressure(double pressure) {
    double p_std = 29.53; // in-hg; standard pressure at sea level
    double fp=0;
    fp = (pressure - p_std)/(p_std);
    return fp;
}

static inline double calcTemperature(double temperature, double altitude) {
    double t_std=-0.0036*altitude+59;
    double FT = (temperature-t_std)/(459.6+t_std);
    return FT;
}

static inline double calcAltitude(double altitude) {
    double fa=0;
    fa=-4e-15*pow(altitude,3)+4e-10*pow(altitude,2)-3e-5*altitude+1;
    return (1/fa);
}



double inline atmosphereCorrection(double ВС, double altitude, double pressure, double temperature, double humidity){
    double correctedBC;
    double cRH = calcRelativeHumidity(temperature, pressure, humidity);
    double cP = calcPressure(pressure);
    double cT = calcTemperature(temperature, altitude);
    double cA = calcAltitude(altitude);


    double cd = (cA*(1+cT-cP)*cRH);

    correctedBC = ВС * cd;
    return correctedBC;
}



double inline Ballistics::calculateFlightTime_VAC(double velocity, double angle) {
    // Convert angle to radians
    double angle_rad = angle * M_PI / 180.0;

    // Calculate the vertical component of initial velocity
    double vy = velocity * sin(angle_rad);

    // Calculate flight time in vacuum
    double flight_time = 2 * vy / GRAVITY;

    return flight_time;
}

double inline Ballistics::calculateZeroAngle(double velocity, double sight, double zeroRange, DragFunction G7, double dragCoefficient, double yIntercept) {
    // Numerical Integration variables
    double t = 0;
    double dt = 1 / velocity; // The solution accuracy generally doesn't suffer if its within a foot for each second of time.
    double y = -sight / 12;
    double x = 0;
    double da; // The change in the bore angle used to iterate in on the correct zero angle.


    double v = 0, vx = 0, vy = 0;
    double vx1 = 0, vy1 = 0;
    double dv = 0, dvx = 0, dvy = 0;
    double Gx = 0, Gy = 0;

    double i_angle = 0;

    int quit = 0;


    da = deg_to_rad(14);



    for (i_angle = 0; quit == 0; i_angle = i_angle + da) {
        vy = velocity * sin(i_angle);
        vx = velocity * cos(i_angle);
        Gx = GRAVITY * sin(i_angle);
        Gy = GRAVITY * cos(i_angle);

        for (t = 0, x = 0, y = -sight / 12; x <= zeroRange * 3; t = t + dt) {
            vy1 = vy;
            vx1 = vx;
            v = pow((pow(vx, 2) + pow(vy, 2)), 0.5);
            dt = 1 / v;

            dv = retard(G7, dragCoefficient, v);
            dvy = -dv * vy / v * dt;
            dvx = -dv * vx / v * dt;

            vx = vx + dvx;
            vy = vy + dvy;
            vy = vy + dt * Gy;
            vx = vx + dt * Gx;

            x = x + dt * (vx + vx1) / 2;
            y = y + dt * (vy + vy1) / 2;
            // Break early to save CPU time if we won't find a solution.
            if (vy < 0 && y < yIntercept) {
                break;
            }
            if (vy > 3 * vx) {
                break;
            }
        }

        if (y > yIntercept && da > 0) {
            da = -da / 2;
        }

        if (y < yIntercept && da < 0) {
            da = -da / 2;
        }

        if (fabs(da) < moa_to_rad(0.01)) quit = 1;
        if (i_angle > deg_to_rad(45)) quit = 1;
    }

    return rad_to_deg(i_angle);
}

double Ballistics::calculateHorizontalDrift(double velocity, double BC, double angle, double distance, double windSpeed, double windDirection, double sight, double altitude, double pressure, double temperature, double humidity, double zeroRange) {
    // Коррекция баллистического коэффициента в зависимости от условий окружающей среды
    double correctedBC = atmosphereCorrection(BC, altitude, pressure, temperature, humidity);

    // Расчет угла пристрелки
    double zeroAngle = calculateZeroAngle(velocity, sight, zeroRange, G7, correctedBC, 0);
    double zeroAngleRad = deg_to_rad(zeroAngle);
    double cosZeroAngle = cos(zeroAngleRad);
    double sinZeroAngle = sin(zeroAngleRad);

    // Учет встречного ветра



    // Расчет начальных компонентов скорости
    double vx = velocity * cosZeroAngle;
    double vy = velocity * sinZeroAngle;
    double vz = 0;

    // Инициализация переменных для численного интегрирования
    double x = 0;
    double y = 0;
    double z = 0;
    double dt = 0.001; // Начальный временной шаг

    auto acceleration = [&](double v) {
        return -retard(G7, correctedBC, v) / v;
    };

    while (x <= distance) {
        double v = sqrt(vx * vx + vy * vy + vz * vz);
        double ax = acceleration(v) * vx;
        double ay = acceleration(v) * vy;
        double az = acceleration(v) * vz;

        x += vx * dt;
        y += vy * dt;
        z += vz * dt;

        vx += ax * dt;
        vy += ay * dt;
        vz += az * dt;

        double crossWindEffect = crosswind(windSpeed, windDirection, angle);
        y += dt * crossWindEffect;
    }

    // Возвращение горизонтального сноса в дюймах
    return y * 12;
}




double Ballistics::headwind(double windSpeed, double windDirection, double angle) {
    return windSpeed * cos(deg_to_rad(windDirection - angle));
}

double Ballistics::crosswind(double windSpeed, double windDirection, double angle) {
    return windSpeed * sin(deg_to_rad(windDirection - angle));
}
