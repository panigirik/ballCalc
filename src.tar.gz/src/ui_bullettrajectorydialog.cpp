#include "ui_bullettrajectorydialog.h"

BulletTrajectoryDialog::BulletTrajectoryDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::BulletTrajectoryDialog)
{
    ui->setupUi(this);
    chartView = new QtCharts::QChartView(this);
    ui->verticalLayout->addWidget(chartView);
}

BulletTrajectoryDialog::~BulletTrajectoryDialog() {
    delete ui;
}

void BulletTrajectoryDialog::setBulletTrajectory(const QVector<double> &distance, const QVector<double> &drop) {
    // Создаем объект для данных графика
    QtCharts::QLineSeries *series = new QtCharts::QLineSeries();

    // Заполняем данные графика
    for (int i = 0; i < distance.size(); ++i) {
        // Получаем падение пули для данной дистанции
        double dropInches = drop[i]; // Используем переданное падение в дюймах
        // Конвертируем падение пули в MOA
        double dropMOA = dropInches / 1.047; // 1 inch = 1.047 MOA
        series->append(distance[i], dropMOA);
    }

    // Создаем график и добавляем данные
    QtCharts::QChart *chart = chartView->chart();
    chart->removeAllSeries();
    chart->addSeries(series);
    chart->createDefaultAxes();

    // Устанавливаем заголовок и метки осей
    chart->setTitle("Траектория полета пули");
    chart->axisX()->setTitleText("Дистанция (yrds)");
    chart->axisY()->setTitleText("Падение (MOA)");

    // Отображаем график
    chartView->update();
}
