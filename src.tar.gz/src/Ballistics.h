#ifndef BALLISTICS_H
#define BALLISTICS_H

#include <cmath>
//#include "drag.h"
#include "/home/zahar/libballistics/include/ballistics/ballistics.h"

class Ballistics {
public:
    // Constructor
    Ballistics();

    // Destructor
    ~Ballistics();

    // Member functions for ballistics calculations
    double calculate_HOR(double velocity, double angle, double caliber, double mass, double BC,
                            double temperature, double pressure, double humidity, double windSpeed,
                            double sight, double zeroRange, double twist, double bulletLength,
                            double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude);

    double calculateMOA_VERT(double velocity, double angle, double caliber, double mass, double BC,
                             double temperature, double pressure, double humidity, double windSpeed,
                             double sight, double zeroRange, double twist, double bulletLength,
                             double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude);


    double calculateSG(double mass, double twist, double bulletLength, double caliber, double velocity, double temperature, double pressure); // Simplified example

    double calculateGroup(double distance, double YrdGroup);

    double calculateFlightTime(double velocity, double angle, double caliber, double mass, double BC,
                                   double temperature, double pressure, double humidity, double windSpeed,
                                   double sight, double zeroRange, double twist, double bulletLength,
                                   double windDirection, double Zapas_Hor, double Zapas_Vert, double distance);


    double calculateVerticalDrop(double velocity, double BC, double angle, double distance, double windSpeed, double windDirection, double sight, double altitude, double pressure, double temperature, double humidity, double zeroRange);



    double calculateMOA_HOR(double velocity, double angle, double caliber, double mass, double BC,
                            double temperature, double pressure, double humidity, double windSpeed,
                            double sight, double zeroRange, double twist, double bulletLength,
                            double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude);


    double calculateMRAD_HOR(double velocity, double angle, double caliber, double mass, double BC,
                             double temperature, double pressure, double humidity, double windSpeed,
                             double sight, double zeroRange, double twist, double bulletLength,
                             double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude);


    double calculateMRAD_VERT(double velocity, double angle, double caliber, double mass, double BC,
                              double temperature, double pressure, double humidity, double windSpeed,
                              double sight, double zeroRange, double twist, double bulletLength,
                              double windDirection, double Zapas_Hor, double Zapas_Vert, double distance, double altitude);

    static double calculateFlightTime_VAC(double velocity, double angle);


    double calculateZeroAngle(double velocity, double sight, double zeroRange, DragFunction  dragFunction, double dragCoefficient, double yIntercept);



    double calculateHorizontalDrift(double velocity, double BC, double angle, double distance, double windSpeed, double windDirection, double sight, double altitude, double pressure, double temperature, double humidity, double zeroRange);


    double headwind(double windSpeed, double windDirection, double angle);

    double crosswind(double windSpeed, double windDirection, double angle);


    double calculateDerivation(double velocity, double angle, double caliber, double mass, double BC,
                                           double temperature, double pressure, double humidity, double windSpeed,
                                           double sight, double zeroRange, double twist, double bulletLength,
                                           double windDirection, double distance, double altitude);

    };





static inline double calcRelativeHumidity(double temperature, double pressure, double humidity);
static inline double calcPressure(double pressure);
static inline double calcTemperature(double temperature, double alttitude);
static inline double calcAltitude(double altitude);

double atmosphereCorrection(double ВС, double altitude, double pressure, double temperature, double humidity);

#endif // BALLISTICS_H
