#ifndef UI_BULLETTRAJECTORYDIALOG_H
#define UI_BULLETTRAJECTORYDIALOG_H

#include <QDialog>
#include <QVector>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>

namespace Ui {
class BulletTrajectoryDialog;
}

class BulletTrajectoryDialog : public QDialog
{
    Q_OBJECT

public:
    explicit BulletTrajectoryDialog(QWidget *parent = nullptr);
    ~BulletTrajectoryDialog();

    void setBulletTrajectory(const QVector<double> &distance, const QVector<double> &drop);

private:
    Ui::BulletTrajectoryDialog *ui;
    QtCharts::QChartView *chartView;
};

#endif // UI_BULLETTRAJECTORYDIALOG_H
